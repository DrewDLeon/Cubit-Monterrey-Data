# CUBIT-PROJECT_HACKATHON
Proyecto oficial de hackathon tigres 2023
